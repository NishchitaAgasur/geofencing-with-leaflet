import React, { useEffect } from 'react';
import './App.css';
import L, { circleMarker, drawLocal, DrawMap, drawVersion, polygon } from "leaflet";
import "leaflet-draw/dist/leaflet.draw.css";
import "leaflet-draw";
import geocoder from 'leaflet-control-geocoder';

var leafletDraw = require('leaflet-draw');



function App() {
  useEffect(() => {
    var map = L.map('mapid').setView([12.9716, 77.5946], 13);
   L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
       attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
   }).addTo(map); 
   
   L.Control.geocoder().addTo(map);

    
   
   
    /*var searchControl = L.esri.Geocoding.geosearch({
     position: 'topright',
    placeholder: 'Enter an address or place e.g. 1 York St',
    useMapBounds: false,
      nearby: {
        lat: -33.8688,
        lng: 151.2093
      }
  }).addTo(map);

  var results = L.layerGroup().addTo(map);

  searchControl.on('results', function (data) {
    results.clearLayers();
    for (var i = data.results.length - 1; i >= 0; i--) {
      results.addLayer(L.marker(data.results[i].latlng));
    }
  });*/


   

   
   
      var drawnItems = new L.FeatureGroup();
      map.addLayer(drawnItems);
      var drawControl = new L.Control.Draw({
      
      	 draw:{
          polygon:false,
          circle:false,
          circlemarker:false,
          rectangle:false

        },
          edit: {
              featureGroup: drawnItems
          }
      });
     map.addControl(drawControl);

    
     map.on(L.Draw.Event.CREATED, function (event) {
      let layer = event.layer;
      drawnItems.addLayer(layer);
  });


   
    /* draws new toolbar (with different drawnItems and e.g. marker: true)*/
   /* var drawnItems = new L.FeatureGroup();
    map.addLayer(drawnItems);
    var drawControl = new L.Control.Draw({
        draw: {
            polygon: true,
            marker: true,
            circle:false
        },
        edit: {
            featureGroup: drawnItems 
        }
    });
    map.addControl(drawControl);

    map.on(L.Draw.Event.CREATED, function( e ) {
        console.log('created');
    });
*/
    

   
    
    });

    

  
  return (
    
     <div id="mapid"></div>
    
  );
}

export default App;
